const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['member', 'admin', 'super-admin'], default: 'member' },
    membershipPlan: { type: mongoose.Schema.Types.ObjectId, ref: 'Plan' },
    membershipStatus: { type: String, enum: ['active', 'inactive', 'pending'], default: 'pending' },
    phone: { type: String },
    paymentMethod: { type: String },
    assignedTrainer: { type: mongoose.Schema.Types.ObjectId, ref: 'Trainer' },
    createdAt: { type: Date, default: Date.now }
});

// Hash password before saving
userSchema.pre('save', async function () {
    if (!this.isModified('password')) return;
    this.password = await bcrypt.hash(this.password, 10);
});

// Compare password
userSchema.methods.comparePassword = async function (candidatePassword) {
    const isMatch = await bcrypt.compare(candidatePassword, this.password);
    if (!isMatch) console.log(`[AUTH] Password mismatch for: ${this.email}`);
    return isMatch;
};

module.exports = mongoose.model('User', userSchema);
